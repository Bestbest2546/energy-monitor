# Change Log
All notable changes to this project will be documented in this file.
## 1.1.0 (2018-07-08)

### Features
* Database management (create or delete database)
* Host connection testing
* Database connection testing